@echo off
title Feathers Systeams
color 0B

setlocal EnableDelayedExpansion

set "PASTA=%~dp0"
set "DIST=%PASTA%dist"

if not exist "%DIST%" (
    echo Pasta dist nao encontrada.
    pause
    exit
)

if not exist "%DIST%\404.ico" (
    echo 404.ico nao encontrado.
    pause
    exit
)

if not exist "%DIST%\susse.ico" (
    echo susse.ico nao encontrado.
    pause
    exit
)

echo Todos os arquivos encontrados.

echo Criando exe.py...
