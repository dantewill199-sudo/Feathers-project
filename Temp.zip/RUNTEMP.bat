@echo off
title Instalador Feathers Systeams
color 0B

setlocal EnableDelayedExpansion

:: ============================================
:: Pastas
:: ============================================

set "ROOT=%SystemDrive%\Temp"
set "DIST=%ROOT%\dist"

echo.
echo ============================================
echo        FEATHERS SYSTEAMS
echo ============================================
echo.

:: Criar pasta principal
if not exist "%ROOT%" (
    mkdir "%ROOT%"
    echo Pasta Temp criada.
)

:: Criar pasta dist
if not exist "%DIST%" (
    mkdir "%DIST%"
    echo Pasta dist criada.
)

echo.

:: ============================================
:: Criando RAM.bat
:: ============================================

echo Criando RAM.bat...

(
echo @echo off
echo title Feathers Systeams
echo color 0B
echo.
echo setlocal EnableDelayedExpansion
echo.
echo set "PASTA=%%~dp0"
echo set "DIST=%%PASTA%%dist"
echo.
echo if not exist "%%DIST%%" ^(
echo     echo Pasta dist nao encontrada.
echo     pause
echo     exit
echo ^)
echo.
echo if not exist "%%DIST%%\404.ico" ^(
echo     echo 404.ico nao encontrado.
echo     pause
echo     exit
echo ^)
echo.
echo if not exist "%%DIST%%\susse.ico" ^(
echo     echo susse.ico nao encontrado.
echo     pause
echo     exit
echo ^)
echo.
echo echo Todos os arquivos encontrados.
echo.
echo echo Criando exe.py...
) > "%ROOT%\RAM.bat"

echo RAM.bat criado.

echo.

:: ============================================
:: Parte 1 concluída
:: ============================================

echo Estrutura inicial criada.
echo Aguarde a Parte 2...

pause
:: ============================================
:: PARTE 2
:: Criando RAM.txt
:: ============================================

echo.
echo Criando RAM.txt...

copy /Y "%ROOT%\RAM.bat" "%ROOT%\RAM.txt" >nul

echo RAM.txt criado.

echo.

:: ============================================
:: Criando arquivo exe.py (placeholder)
:: ============================================

echo Criando exe.py...

(
echo # =====================================
echo # Feathers Systeams
echo # Arquivo gerado automaticamente
echo # =====================================
echo.
echo # O codigo completo sera inserido
echo # nas proximas partes do projeto.
echo.
echo print("Feathers Systeams")
) > "%ROOT%\exe.py"

echo exe.py criado.

echo.

:: ============================================
:: Verificando pasta dist
:: ============================================

if exist "%DIST%\404.ico" (
    echo [OK] 404.ico encontrado.
) else (
    echo [ERRO] 404.ico nao encontrado.
)

if exist "%DIST%\susse.ico" (
    echo [OK] susse.ico encontrado.
) else (
    echo [ERRO] susse.ico nao encontrado.
)

echo.
echo Parte 2 concluida.
echo Aguarde a Parte 3.
pause
:: ============================================
:: PARTE 3
:: Finalização do instalador
:: ============================================

echo.
echo ============================================
echo        INSTALACAO CONCLUIDA
echo ============================================
echo.

echo Pasta principal:
echo %ROOT%
echo.

echo Arquivos criados:
echo.
echo    RAM.bat
echo    RAM.txt
echo    exe.py
echo.

if exist "%DIST%\404.ico" (
    echo [OK] 404.ico
) else (
    echo [AVISO] Falta 404.ico
)

if exist "%DIST%\susse.ico" (
    echo [OK] susse.ico
) else (
    echo [AVISO] Falta susse.ico
)

echo.
echo ============================================
echo.

choice /c ANS /n /m "Abrir a pasta Temp(A), Executar RAM(R) ou Sair(S)? "

if errorlevel 3 goto fim
if errorlevel 2 goto ram
if errorlevel 1 goto abrir

:abrir
start "" "%ROOT%"
goto fim

:ram
start "" "%ROOT%\RAM.bat"
goto fim

:fim
echo.
echo Obrigado por usar o instalador.
timeout /t 2 >nul
exit